// passOO — puente entre la página y la app de escritorio (native messaging).
// La extensión no guarda nada: cada petición va a la app, que tiene el vault
// descifrado en memoria.

const HOST = "io.github.passoo";

function nativo(msg) {
  return new Promise((res) => {
    chrome.runtime.sendNativeMessage(HOST, msg, (r) => {
      if (chrome.runtime.lastError) {
        res({ ok: false, error: "sin_app", detalle: chrome.runtime.lastError.message });
      } else {
        res(r || { ok: false, error: "sin_respuesta" });
      }
    });
  });
}

// Credenciales para una página: solo de entradas que encajan con esa URL,
// para que un marco de otra web no pueda pedir contraseñas ajenas.
async function credencialesPara(url, id) {
  const r = await nativo({ op: "para_url", url });
  if (!r.ok || !r.items.some((i) => i.id === id)) return { ok: false, error: "no_encaja" };
  return nativo({ op: "credenciales", id });
}

async function rellenarPestana(tab, id) {
  const cred = id ? await nativo({ op: "credenciales", id }) : null;
  let c = cred;
  if (!c) {
    const r = await nativo({ op: "para_url", url: tab.url });
    if (!r.ok || !r.items.length) return r.ok ? { ok: false, error: "sin_entradas" } : r;
    c = await nativo({ op: "credenciales", id: r.items[0].id });
  }
  if (c.ok) chrome.tabs.sendMessage(tab.id, { tipo: "rellenar", cred: c });
  return c.ok ? { ok: true } : c;
}

const TEXTOS = {
  sin_app: "Abre la app passOO en este Mac para rellenar.",
  cerrada: "Abre la app passOO en este Mac para rellenar.",
  bloqueado: "passOO está bloqueado: desbloquéalo en la app.",
  sin_entradas: "passOO no tiene entradas para esta web.",
};
const avisar = (tab, r) =>
  chrome.tabs.sendMessage(tab.id, { tipo: "aviso", texto: TEXTOS[r.error] || "No se pudo conectar con passOO." }, { frameId: 0 });

// Contraseñas enviadas en formularios, pendientes de «¿Guardar en passOO?».
// Se guardan aquí porque la página suele cambiar justo después de enviar.
const pendientes = new Map(); // tabId → { url, usuario, password, estado, id, nombre, t }

function ofrecer(tabId) {
  const p = pendientes.get(tabId);
  if (!p) return;
  if (Date.now() - p.t > 90000) return pendientes.delete(tabId);
  chrome.tabs.sendMessage(tabId, { tipo: "ofrecer_guardar", estado: p.estado, usuario: p.usuario, nombre: p.nombre }, { frameId: 0 }).catch(() => {});
}
chrome.tabs.onUpdated.addListener((id, info) => info.status === "complete" && ofrecer(id));
chrome.tabs.onRemoved.addListener((id) => pendientes.delete(id));

async function detectada(tab, m) {
  if (!tab || !m.password) return;
  const ant = pendientes.get(tab.id);
  if (ant && ant.password === m.password && ant.usuario === m.usuario) return;
  const r = await nativo({ op: "comprobar", url: tab.url, usuario: m.usuario, password: m.password });
  if (!r.ok || r.estado === "igual") return;
  pendientes.set(tab.id, { url: tab.url, usuario: m.usuario, password: m.password, estado: r.estado, id: r.id, nombre: r.nombre, t: Date.now() });
  setTimeout(() => ofrecer(tab.id), 400); // por si la página no cambia (webs SPA)
}

async function responderGuardado(tab, guardar) {
  const p = tab && pendientes.get(tab.id);
  if (!p) return { ok: false };
  pendientes.delete(tab.id);
  if (!guardar) return { ok: true };
  let uri = p.url;
  try {
    uri = new URL(p.url).origin;
  } catch {}
  const r = await nativo({ op: "guardar_entrada", id: p.estado === "cambiada" ? p.id : undefined, nombre: p.nombre, usuario: p.usuario, password: p.password, uri });
  chrome.tabs.sendMessage(tab.id, { tipo: "aviso", texto: r.ok ? (r.creada ? "Entrada guardada." : "Contraseña actualizada.") : `No se pudo guardar: ${r.error || "error"}` }, { frameId: 0 });
  if (r.ok) contador(tab.id, tab.url);
  return r;
}

chrome.runtime.onMessage.addListener((m, sender, send) => {
  (async () => {
    const desdePagina = !!sender.tab;
    switch (m.tipo) {
      case "para_url":
        send(await nativo({ op: "para_url", url: desdePagina ? sender.url : m.url }));
        break;
      case "detectada":
        if (desdePagina) detectada(sender.tab, m);
        send({ ok: true });
        break;
      case "responder_guardado":
        send(desdePagina ? await responderGuardado(sender.tab, !!m.guardar) : { ok: false });
        break;
      case "guardar_entrada":
        send(desdePagina ? { ok: false } : await nativo({ op: "guardar_entrada", nombre: m.nombre, usuario: m.usuario, password: m.password, uri: m.uri, notas: m.notas }));
        break;
      case "leer_campos": {
        if (desdePagina) return send({ ok: false });
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) return send({ ok: false });
        chrome.tabs.sendMessage(tab.id, { tipo: "leer_campos" }, (r) => {
          void chrome.runtime.lastError;
          send({ ok: true, url: tab.url, ...(r || {}) });
        });
        break;
      }
      case "generar":
        send(desdePagina ? { ok: false } : await nativo({ op: "generar", opciones: m.opciones }));
        break;
      case "copiar_texto":
        send(desdePagina ? { ok: false } : await nativo({ op: "copiar_texto", texto: m.texto }));
        break;
      case "poner_password": {
        if (desdePagina) return send({ ok: false });
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab) chrome.tabs.sendMessage(tab.id, { tipo: "poner_password", valor: m.valor });
        send({ ok: !!tab });
        break;
      }
      case "estado":
        send(desdePagina ? { ok: false } : await nativo({ op: "estado" }));
        break;
      case "mostrar":
        send(desdePagina ? { ok: false } : await nativo({ op: "mostrar", id: m.id }));
        break;
      case "abrir_app": {
        const r = desdePagina ? { ok: false } : await nativo({ op: "abrir_app" });
        marcarConexion(!!r.ok);
        send(r);
        break;
      }
      case "ajustes":
        send(await chrome.storage.local.get({ autoRellenar: true }));
        break;
      case "credenciales":
        send(desdePagina ? await credencialesPara(sender.url, m.id) : { ok: false });
        break;
      case "buscar":
        send(desdePagina ? { ok: false } : await nativo({ op: "buscar", q: m.q, tipo: m.vista }));
        break;
      case "copiar":
        send(desdePagina ? { ok: false } : await nativo({ op: "copiar", id: m.id, campo: m.campo }));
        break;
      case "rellenar_en_pestana": {
        if (desdePagina) return send({ ok: false });
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        send(tab ? await rellenarPestana(tab, m.id) : { ok: false });
        break;
      }
      default:
        send({ ok: false });
    }
  })();
  return true;
});

// Icono en color con la app abierta y desbloqueada; en gris si no.
const ICONOS = (p) => ({ 16: `iconos/${p}16.png`, 32: `iconos/${p}32.png` });
let conectada = null;
function marcarConexion(ok) {
  if (ok === conectada) return;
  conectada = ok;
  chrome.action.setIcon({ path: ICONOS(ok ? "" : "gris-") });
  chrome.action.setTitle({ title: ok ? "passOO" : "passOO · app cerrada o bloqueada" });
  if (!ok) chrome.action.setBadgeText({ text: "" });
}
// Extensión cargada desde la carpeta (modo desarrollador): si en disco hay una
// versión nueva, se recarga sola (no hace falta pulsar ↻ en brave://extensions).
async function autoActualizar() {
  try {
    const m = await (await fetch(chrome.runtime.getURL("manifest.json"), { cache: "no-store" })).json();
    if (m.version && m.version !== chrome.runtime.getManifest().version) chrome.runtime.reload();
  } catch {}
}

async function comprobar() {
  autoActualizar();
  const r = await nativo({ op: "estado" });
  marcarConexion(!!r.ok);
  return r;
}
chrome.runtime.onStartup.addListener(comprobar);
chrome.runtime.onInstalled.addListener(comprobar);
chrome.alarms.create("passoo", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(comprobar);
comprobar();

// Número de entradas de la web en el icono de la extensión (como la oficial).
async function contador(tabId, url) {
  if (!url || !/^https?:/.test(url)) return chrome.action.setBadgeText({ tabId, text: "" });
  const r = await nativo({ op: "para_url", url });
  marcarConexion(!!r.ok);
  const n = r.ok ? r.items.length : 0;
  chrome.action.setBadgeBackgroundColor({ tabId, color: "#4f86f7" });
  chrome.action.setBadgeTextColor && chrome.action.setBadgeTextColor({ tabId, color: "#ffffff" });
  chrome.action.setBadgeText({ tabId, text: n ? (n > 99 ? "99+" : String(n)) : "" });
}
chrome.tabs.onUpdated.addListener((id, info, tab) => {
  if (info.status === "complete" || info.url) contador(id, tab.url);
});
chrome.tabs.onActivated.addListener(({ tabId }) => chrome.tabs.get(tabId, (t) => t && contador(tabId, t.url)));
chrome.windows.onFocusChanged.addListener(async () => {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (t) contador(t.id, t.url);
});

chrome.commands.onCommand.addListener(async (cmd, tab) => {
  if (cmd !== "rellenar") return;
  const t = tab || (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (!t) return;
  const r = await rellenarPestana(t, null);
  if (!r.ok) avisar(t, r);
});
