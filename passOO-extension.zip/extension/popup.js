const $ = (s) => document.querySelector(s);
const lista = $("#lista");
const pie = $("#pie");
let filas = [];
let sel = 0;
let tab = null;
let vista = "web";
let servidor = "";

const enviar = (m) => chrome.runtime.sendMessage(m);
const DESCARGA = "https://raw.githubusercontent.com/imr7997rmi/nivvoo-apps/main/passOO-latest.zip";

// Iconos de trazo (estilo SF Symbols).
const ICONOS = {
  rellenar: `<svg viewBox="0 0 16 16"><path d="M13 3v4.5a2 2 0 0 1-2 2H3"/><path d="M6 6.5l-3 3 3 3"/></svg>`,
  usuario: `<svg viewBox="0 0 16 16"><circle cx="8" cy="5.5" r="2.7"/><path d="M2.8 14c.6-2.8 2.7-4.3 5.2-4.3s4.6 1.5 5.2 4.3"/></svg>`,
  clave: `<svg viewBox="0 0 16 16"><circle cx="5" cy="8" r="2.8"/><path d="M7.8 8h6M12 8v2.5M14 8v1.8"/></svg>`,
  web: `<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="6"/><ellipse cx="8" cy="8" rx="2.6" ry="6"/><path d="M2 8h12M3 4.8h10M3 11.2h10"/></svg>`,
  editar: `<svg viewBox="0 0 16 16"><path d="M10.6 2.6l2.8 2.8L5.8 13H3v-2.8z"/><path d="M9.2 4l2.8 2.8"/></svg>`,
  copiar: `<svg viewBox="0 0 16 16"><rect x="5" y="5" width="8.5" height="9" rx="1.5"/><path d="M3 10.5V3.5A1.5 1.5 0 0 1 4.5 2H10"/></svg>`,
  tarjeta: `<svg viewBox="0 0 16 16"><rect x="1.8" y="3.5" width="12.4" height="9" rx="1.5"/><path d="M1.8 6.5h12.4M4 10.2h3"/></svg>`,
  identidad: `<svg viewBox="0 0 16 16"><rect x="1.8" y="3" width="12.4" height="10" rx="1.5"/><circle cx="6" cy="7.2" r="1.6"/><path d="M3.6 11c.4-1.3 1.3-2 2.4-2s2 .7 2.4 2M10 6.5h2.5M10 9h2.5"/></svg>`,
  nota: `<svg viewBox="0 0 16 16"><path d="M4 2h5.5L12.5 5v8.5a.5.5 0 0 1-.5.5H4a.5.5 0 0 1-.5-.5v-11A.5.5 0 0 1 4 2z"/><path d="M9.5 2v3h3M5.8 8.5h4.4M5.8 11h4.4"/></svg>`,
  llave: `<svg viewBox="0 0 16 16"><circle cx="5" cy="8" r="3"/><path d="M8 8h6.5M12 8v2.6M14.5 8v2"/></svg>`,
  capas: `<svg viewBox="0 0 16 16"><path d="M8 1.8l6.5 3.3L8 8.4 1.5 5.1z"/><path d="M1.5 8.6 8 11.9l6.5-3.3M1.5 11.6 8 14.9l6.5-3.3"/></svg>`,
  archivo: `<svg viewBox="0 0 16 16"><rect x="1.5" y="2" width="13" height="3.5" rx="1"/><path d="M2.5 5.5v8h11v-8M6 8.5h4"/></svg>`,
  numero: `<svg viewBox="0 0 16 16"><path d="M3 6h10M3 10h10M6.5 3l-1 10M10.5 3l-1 10"/></svg>`,
};

// Acciones de cada fila según el tipo de entrada.
const ACCIONES = {
  login: [["rellenar", "rellenar", "Rellenar usuario y contraseña", true], ["usuario", "usuario", "Copiar usuario"],
    ["password", "clave", "Copiar contraseña"], ["web", "web", "Ir a la web"], ["ver", "editar", "Editar en passOO"]],
  tarjeta: [["rellenar", "rellenar", "Rellenar la tarjeta en esta página", true], ["numero", "numero", "Copiar número"],
    ["cvv", "clave", "Copiar CVV"], ["ver", "editar", "Ver en passOO"]],
  identidad: [["rellenar", "rellenar", "Rellenar nombre, email, dirección…", true], ["email", "copiar", "Copiar email"],
    ["ver", "editar", "Ver en passOO"]],
  nota: [["nota", "copiar", "Copiar la nota"], ["ver", "editar", "Ver en passOO"]],
  otro: [["ver", "editar", "Ver en passOO"]],
};

function error(r) {
  const noInstalada = r.error === "sin_app" && /not found|no encontr/i.test(r.detalle || "");
  if (noInstalada) return { texto: "passOO no está instalado en este Mac.", boton: "Descargar passOO", url: DESCARGA };
  if (r.error === "bloqueado") return { texto: "passOO está bloqueado.", boton: "Abrir passOO" };
  if (r.error === "sin_app" || r.error === "cerrada") return { texto: "passOO no está abierto.", boton: "Abrir passOO" };
  return { texto: "No se pudo conectar con passOO.", boton: "Abrir passOO" };
}

function host(u) {
  try {
    return new URL(/^[a-z]+:\/\//i.test(u) ? u : "https://" + u).hostname;
  } catch {
    return "";
  }
}

// Icono de la web desde el propio Vaultwarden (como la app oficial), o la inicial.
function favicon(it) {
  const d = document.createElement("div");
  d.className = "fav";
  if (it.tipo && it.tipo !== "login") {
    d.innerHTML = ICONOS[it.tipo] || ICONOS.nota;
    return d;
  }
  d.textContent = (it.nombre || "?").trim().charAt(0).toUpperCase();
  const h = host(it.uri || "");
  if (servidor && h) {
    const img = new Image();
    img.onload = () => {
      d.textContent = "";
      d.appendChild(img);
    };
    img.src = `${servidor}/icons/${h}/icon.png`;
  }
  return d;
}

function pintar(secciones) {
  lista.innerHTML = "";
  filas = [];
  for (const [titulo, items] of secciones) {
    if (!items.length) continue;
    const s = document.createElement("div");
    s.className = "seccion";
    s.textContent = titulo;
    lista.appendChild(s);
    for (const it of items) {
      const f = document.createElement("div");
      f.className = "fila";
      f.appendChild(favicon(it));
      const info = document.createElement("div");
      info.className = "info";
      info.innerHTML = `<div class="n"></div><div class="u"></div>`;
      info.querySelector(".n").textContent = it.nombre;
      info.querySelector(".u").textContent = it.sub || it.usuario || "";
      f.appendChild(info);
      for (const [c, ic, t, principal] of ACCIONES[it.tipo || "login"] || ACCIONES.otro) {
        if (c === "web" && !it.uri) continue;
        const b = document.createElement("button");
        b.className = "ic" + (principal ? " principal" : "");
        b.dataset.c = c;
        b.title = t;
        b.innerHTML = ICONOS[ic];
        f.appendChild(b);
      }
      f.addEventListener("click", (e) => accion(it, (e.target.dataset && e.target.dataset.c) || "fila"));
      lista.appendChild(f);
      filas.push([f, it]);
    }
  }
  if (!filas.length) {
    lista.innerHTML = `<div class="aviso"></div>`;
    lista.firstChild.textContent =
      vista === "web" ? "No hay entradas para esta web. Escribe para buscar o elige otra sección." : "Sin resultados.";
  }
  sel = 0;
  marcar();
}

function accion(it, c) {
  if (c === "fila") c = (ACCIONES[it.tipo || "login"] || ACCIONES.otro)[0][0];
  if (c === "rellenar") return rellenar(it);
  if (c === "ver") return ver(it);
  if (c === "web") return web(it);
  copiar(it, c);
}

function marcar() {
  filas.forEach(([f], i) => f.classList.toggle("sel", i === sel));
  if (filas[sel]) filas[sel][0].scrollIntoView({ block: "nearest" });
}

function web(it) {
  const u = /^[a-z]+:\/\//i.test(it.uri) ? it.uri : "https://" + it.uri;
  chrome.tabs.create({ url: u });
  window.close();
}

async function ver(it) {
  const r = await enviar({ tipo: "mostrar", id: it.id });
  if (r && r.ok) window.close();
  else aviso(error(r || {}));
}

async function rellenar(it) {
  const r = await enviar({ tipo: "rellenar_en_pestana", id: it.id });
  if (r && r.ok) window.close();
  else aviso(error(r || {}));
}

const NOMBRES = { usuario: "Usuario", password: "Contraseña", numero: "Número", cvv: "CVV", email: "Email", nota: "Nota" };
async function copiar(it, campo) {
  const r = await enviar({ tipo: "copiar", id: it.id, campo });
  if (r && r.ok) {
    pie.textContent = `${NOMBRES[campo] || "Dato"} copiado · se borra en 30 s`;
    pie.className = "ok";
  } else if (r && r.error === "vacío") {
    pie.textContent = `Esta entrada no tiene ${(NOMBRES[campo] || "ese dato").toLowerCase()}`;
    pie.className = "";
  } else aviso(error(r || {}));
}

function aviso(e) {
  if (typeof e === "string") e = { texto: e };
  lista.innerHTML = `<div class="aviso"><div></div></div>`;
  lista.querySelector(".aviso div").textContent = e.texto;
  filas = [];
  if (!e.boton) return;
  const b = document.createElement(e.url ? "a" : "button");
  b.className = "accion";
  b.textContent = e.boton;
  if (e.url) {
    b.href = e.url;
    b.target = "_blank";
  } else {
    b.addEventListener("click", async () => {
      b.textContent = "Abriendo…";
      b.disabled = true;
      await enviar({ tipo: "abrir_app" });
      cargar();
    });
  }
  lista.querySelector(".aviso").appendChild(b);
}

// Icono de cada sección (los mismos dibujos que en la app).
const ICONO_VISTA = { web: "web", todo: "capas", login: "llave", tarjeta: "tarjeta", identidad: "identidad", nota: "nota", archivo: "archivo" };
document.querySelectorAll("#vistas button").forEach((b) => b.insertAdjacentHTML("afterbegin", ICONOS[ICONO_VISTA[b.dataset.v]]));

const TITULOS = { todo: "Resultados", login: "Entradas", tarjeta: "Tarjetas", identidad: "Identidades", nota: "Notas seguras", archivo: "Archivo" };

async function cargar() {
  const q = $("#q").value.trim();
  if (!servidor) {
    const e = await enviar({ tipo: "estado" });
    if (e && e.ok) servidor = e.servidor || "";
  }
  let r;
  if (vista === "web" && !q) {
    if (!tab) [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    r = await enviar({ tipo: "para_url", url: tab ? tab.url : "" });
    if ($("#q").value.trim() !== q) return;
    if (!r || !r.ok) return aviso(error(r || {}));
    return pintar([["Entrada actual", r.items]]);
  }
  r = await enviar({ tipo: "buscar", q, vista: vista === "web" ? "todo" : vista });
  if ($("#q").value.trim() !== q) return; // ya se escribió otra cosa
  if (!r || !r.ok) return aviso(error(r || {}));
  pintar([[TITULOS[vista] || "Resultados", r.items]]);
}

let temporizador = null;
$("#q").addEventListener("input", () => {
  clearTimeout(temporizador);
  temporizador = setTimeout(cargar, 60);
});

$("#vistas").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  const v = b && b.dataset.v;
  if (!v) return;
  vista = v;
  document.querySelectorAll("#vistas button").forEach((b) => b.classList.toggle("on", b.dataset.v === v));
  $("#q").placeholder = v === "web" ? "Buscar en passOO…" : `Buscar en ${b.title.toLowerCase()}…`;
  $("#q").focus();
  cargar();
});

document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowDown" || e.key === "ArrowUp") {
    e.preventDefault();
    if (!filas.length) return;
    sel = (sel + (e.key === "ArrowDown" ? 1 : filas.length - 1)) % filas.length;
    marcar();
  } else if (e.key === "Enter" && filas[sel]) {
    e.preventDefault();
    accion(filas[sel][1], "fila");
  }
});

chrome.storage.local.get({ autoRellenar: true }).then((a) => ($("#autoRellenar").checked = a.autoRellenar));
$("#autoRellenar").addEventListener("change", (e) => chrome.storage.local.set({ autoRellenar: e.target.checked }));

cargar();
