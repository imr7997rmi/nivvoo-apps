// passOO — detecta los campos de acceso de la página y ofrece las entradas
// de la app. Solo dibuja el menú y rellena; no guarda nada.
(() => {
  if (window.__passoo) return;
  window.__passoo = true;

  let items = null;
  let pedido = null;
  let campo = null; // input con el menú abierto
  let caja = null; // host del shadow DOM
  let raiz = null;
  let elegido = 0;

  const pedir = () => {
    if (!pedido) {
      pedido = chrome.runtime
        .sendMessage({ tipo: "para_url" })
        .then((r) => (items = r && r.ok ? r.items : []))
        .catch(() => (items = []));
    }
    return pedido;
  };

  // ── Detección de campos ────────────────────────────────────────────────
  const visible = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 20 || r.height < 10) return false;
    const s = getComputedStyle(el);
    return s.visibility !== "hidden" && s.display !== "none" && s.opacity !== "0";
  };
  const texto = (el) =>
    [el.name, el.id, el.placeholder, el.getAttribute("aria-label"), el.autocomplete]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();
  const tipo = (el) => (el.type || "text").toLowerCase();

  const esPassword = (el) => el instanceof HTMLInputElement && tipo(el) === "password";
  const esOtp = (el) =>
    el instanceof HTMLInputElement &&
    tipo(el) !== "password" &&
    ((el.autocomplete || "").toLowerCase() === "one-time-code" ||
      /\b(otp|totp|2fa|mfa)\b|one.?time|c[oó]digo|verification.?code|auth.?code/.test(texto(el)));
  const esUsuario = (el) => {
    if (!(el instanceof HTMLInputElement)) return false;
    if (!["text", "email", "tel"].includes(tipo(el)) || esOtp(el)) return false;
    const a = (el.autocomplete || "").toLowerCase();
    if (a.includes("username") || a === "email") return true;
    if (tipo(el) === "email") return true;
    return /user|usuari|login|e-?mail|correo|account|cuenta|nif|dni|identif|ident/.test(texto(el));
  };

  const inputs = (r = document) => [...r.querySelectorAll("input")].filter(visible);

  function usuarioPara(pw) {
    const lista = inputs(pw.form || document);
    const i = lista.indexOf(pw);
    for (let k = i - 1; k >= 0; k--) {
      const e = lista[k];
      if (["text", "email", "tel"].includes(tipo(e)) && !esOtp(e)) return e;
    }
    return lista.find(esUsuario) || null;
  }

  // Campos de acceso: contraseña, usuario (también el paso 1 de los login en dos pasos) u OTP.
  // El menú solo aparece si la app tiene entradas para esta web.
  const esCampoDeAcceso = (el) => esPassword(el) || esOtp(el) || esUsuario(el);

  // ── Rellenar ───────────────────────────────────────────────────────────
  function poner(el, v) {
    if (!el || v == null || v === "") return;
    el.focus();
    const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    d.set.call(el, v);
    for (const t of ["input", "change"]) el.dispatchEvent(new Event(t, { bubbles: true }));
  }

  function rellenar(cred, foco) {
    if (foco && esOtp(foco) && cred.totp) return poner(foco, cred.totp);
    const pws = inputs().filter(esPassword);
    if (pws.length) {
      const pw = foco && esPassword(foco) ? foco : pws[0];
      const u = usuarioPara(pw);
      if (u && cred.usuario) poner(u, cred.usuario);
      poner(pw, cred.password);
      return;
    }
    const otp = inputs().find(esOtp);
    if (otp && cred.totp && (!foco || foco === otp)) return poner(otp, cred.totp);
    const u = foco && esUsuario(foco) ? foco : inputs().find(esUsuario);
    if (u) poner(u, cred.usuario);
  }

  // Aviso breve en la página (atajo sin app abierta, bloqueada…).
  function aviso(texto) {
    const h = document.createElement("passoo-aviso");
    const r = h.attachShadow({ mode: "closed" });
    r.innerHTML = `<style>div{position:fixed;z-index:2147483647;top:16px;right:16px;max-width:340px;padding:10px 14px;
      background:#1c1c1e;color:#f2f2f2;border:1px solid #3a3a3c;border-radius:10px;box-shadow:0 8px 28px rgba(0,0,0,.35);
      font:13px -apple-system,BlinkMacSystemFont,sans-serif}b{background:linear-gradient(135deg,#1698e7,#5b3ee6);
      -webkit-background-clip:text;color:transparent}</style><div><b>passOO</b> · </div>`;
    r.querySelector("div").append(texto);
    document.documentElement.appendChild(h);
    setTimeout(() => h.remove(), 4000);
  }

  chrome.runtime.onMessage.addListener((m) => {
    if (m.tipo === "aviso" && window === top) aviso(m.texto);
    if (m.tipo === "rellenar" && m.cred) {
      const foco = document.activeElement instanceof HTMLInputElement ? document.activeElement : null;
      if (inputs().some((e) => esPassword(e) || esUsuario(e) || esOtp(e))) rellenar(m.cred, foco);
    }
  });

  // ── Menú junto al campo ─────────────────────────────────────────────────
  const CSS = `
    :host { all: initial; }
    .menu { position: fixed; z-index: 2147483647; min-width: 260px; max-width: 380px;
      background: #1c1c1e; color: #f2f2f2; border: 1px solid #3a3a3c; border-radius: 10px;
      box-shadow: 0 8px 28px rgba(0,0,0,.35); font: 13px -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif;
      overflow: hidden; }
    .cab { display: flex; align-items: center; gap: 8px; padding: 8px 12px; font-size: 11px; color: #8e8e93;
      border-bottom: 1px solid #2c2c2e; }
    .logo { width: 16px; height: 16px; }
    .fila { padding: 8px 12px; cursor: pointer; }
    .fila.sel, .fila:hover { background: rgba(79,134,247,.22); }
    .n { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .u { color: #8e8e93; font-size: 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .aviso { padding: 10px 12px; color: #8e8e93; }`;

  function cerrar() {
    if (caja) caja.remove();
    caja = raiz = campo = null;
  }

  function colocar() {
    if (!caja || !campo) return;
    const r = campo.getBoundingClientRect();
    const m = raiz.querySelector(".menu");
    m.style.left = Math.max(4, r.left) + "px";
    m.style.top = r.bottom + 4 + "px";
    m.style.minWidth = Math.max(260, r.width) + "px";
  }

  function pintar() {
    const m = raiz.querySelector(".menu");
    const otp = esOtp(campo);
    const lista = otp ? items.filter((i) => i.totp) : items;
    m.innerHTML = `<div class="cab"><img class="logo" src="${chrome.runtime.getURL("iconos/32.png")}">passOO${otp ? " · código TOTP" : ""}</div>`;
    lista.forEach((it, i) => {
      const f = document.createElement("div");
      f.className = "fila" + (i === elegido ? " sel" : "");
      f.innerHTML = `<div class="n"></div><div class="u"></div>`;
      f.querySelector(".n").textContent = it.nombre;
      f.querySelector(".u").textContent = it.usuario || "";
      f.addEventListener("mousedown", (e) => {
        e.preventDefault();
        usar(it);
      });
      m.appendChild(f);
    });
  }

  async function usar(it) {
    const el = campo;
    cerrar();
    const c = await chrome.runtime.sendMessage({ tipo: "credenciales", id: it.id });
    if (c && c.ok) rellenar(c, el);
  }

  async function abrir(el) {
    await pedir();
    if (!items || !items.length || document.activeElement !== el) return;
    if (esOtp(el) && !items.some((i) => i.totp)) return;
    if (campo === el && caja) return;
    cerrar();
    campo = el;
    elegido = 0;
    caja = document.createElement("passoo-menu");
    raiz = caja.attachShadow({ mode: "closed" });
    raiz.innerHTML = `<style>${CSS}</style><div class="menu"></div>`;
    document.documentElement.appendChild(caja);
    pintar();
    colocar();
  }

  document.addEventListener(
    "focusin",
    (e) => {
      const el = e.target;
      if (el instanceof HTMLInputElement && visible(el) && esCampoDeAcceso(el)) {
        abrir(el);
      } else if (campo && el !== campo) {
        cerrar();
      }
    },
    true
  );
  document.addEventListener("focusout", (e) => {
    if (e.target === campo) setTimeout(() => document.activeElement !== campo && cerrar(), 150);
  }, true);
  document.addEventListener(
    "keydown",
    (e) => {
      if (!caja || e.target !== campo) return;
      const n = raiz.querySelectorAll(".fila").length;
      if (e.key === "Escape") return cerrar();
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        elegido = (elegido + (e.key === "ArrowDown" ? 1 : n - 1)) % Math.max(n, 1);
        pintar();
      } else if (e.key === "Enter" && n) {
        const lista = esOtp(campo) ? items.filter((i) => i.totp) : items;
        if (lista[elegido]) {
          e.preventDefault();
          usar(lista[elegido]);
        }
      } else if (e.key.length === 1) {
        cerrar(); // si escribe a mano, el menú se aparta
      }
    },
    true
  );
  window.addEventListener("scroll", colocar, true);
  window.addEventListener("resize", colocar);

  // ── Rellenar al cargar la página ────────────────────────────────────────
  // Como la opción «Autorrellenar al cargar» de Bitwarden: solo en el marco
  // principal, con una única entrada para la web y un campo de contraseña
  // visible. También vale para formularios que aparecen después (webs SPA).
  let autoHecho = false;
  async function autoRellenar() {
    if (autoHecho || window !== top) return;
    if (!inputs().some(esPassword)) return;
    autoHecho = true;
    const a = await chrome.runtime.sendMessage({ tipo: "ajustes" }).catch(() => null);
    if (!a || !a.autoRellenar) return;
    await pedir();
    if (items.length !== 1) return;
    const pws = inputs().filter(esPassword);
    if (pws.some((p) => p.value) ) return; // no pisar lo que ya haya
    const c = await chrome.runtime.sendMessage({ tipo: "credenciales", id: items[0].id });
    if (c && c.ok) rellenar(c, null);
  }
  autoRellenar();
  if (window === top) {
    const obs = new MutationObserver(() => autoRellenar());
    obs.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(() => obs.disconnect(), 15000);
  }

  // Si la página ya tiene el foco en un campo al cargar.
  if (document.activeElement instanceof HTMLInputElement) {
    document.activeElement.dispatchEvent(new FocusEvent("focusin", { bubbles: true }));
  }
})();
