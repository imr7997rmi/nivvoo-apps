// passOO — puente entre la página y la app de escritorio (native messaging).
// La extensión no guarda nada: cada petición va a la app, que tiene el vault
// descifrado en memoria.

const HOST = "io.github.passoo";

function nativo(msg) {
  return new Promise((res) => {
    chrome.runtime.sendNativeMessage(HOST, msg, (r) => {
      if (chrome.runtime.lastError) {
        res({ ok: false, error: "sin_app", detalle: chrome.runtime.lastError.message });
      } else {
        res(r || { ok: false, error: "sin_respuesta" });
      }
    });
  });
}

// Credenciales para una página: solo de entradas que encajan con esa URL,
// para que un marco de otra web no pueda pedir contraseñas ajenas.
async function credencialesPara(url, id) {
  const r = await nativo({ op: "para_url", url });
  if (!r.ok || !r.items.some((i) => i.id === id)) return { ok: false, error: "no_encaja" };
  return nativo({ op: "credenciales", id });
}

async function rellenarPestana(tab, id) {
  const cred = id ? await nativo({ op: "credenciales", id }) : null;
  let c = cred;
  if (!c) {
    const r = await nativo({ op: "para_url", url: tab.url });
    if (!r.ok || !r.items.length) return r.ok ? { ok: false, error: "sin_entradas" } : r;
    c = await nativo({ op: "credenciales", id: r.items[0].id });
  }
  if (c.ok) chrome.tabs.sendMessage(tab.id, { tipo: "rellenar", cred: c });
  return c.ok ? { ok: true } : c;
}

chrome.runtime.onMessage.addListener((m, sender, send) => {
  (async () => {
    const desdePagina = !!sender.tab;
    switch (m.tipo) {
      case "para_url":
        send(await nativo({ op: "para_url", url: desdePagina ? sender.url : m.url }));
        break;
      case "credenciales":
        send(desdePagina ? await credencialesPara(sender.url, m.id) : { ok: false });
        break;
      case "buscar":
        send(desdePagina ? { ok: false } : await nativo({ op: "buscar", q: m.q }));
        break;
      case "copiar":
        send(desdePagina ? { ok: false } : await nativo({ op: "copiar", id: m.id, campo: m.campo }));
        break;
      case "rellenar_en_pestana": {
        if (desdePagina) return send({ ok: false });
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        send(tab ? await rellenarPestana(tab, m.id) : { ok: false });
        break;
      }
      default:
        send({ ok: false });
    }
  })();
  return true;
});

chrome.commands.onCommand.addListener(async (cmd, tab) => {
  if (cmd !== "rellenar") return;
  const t = tab || (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (t) rellenarPestana(t, null);
});
