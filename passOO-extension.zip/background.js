// passOO — puente entre la página y la app de escritorio (native messaging).
// La extensión no guarda nada: cada petición va a la app, que tiene el vault
// descifrado en memoria.

const HOST = "io.github.passoo";

function nativo(msg) {
  return new Promise((res) => {
    chrome.runtime.sendNativeMessage(HOST, msg, (r) => {
      if (chrome.runtime.lastError) {
        res({ ok: false, error: "sin_app", detalle: chrome.runtime.lastError.message });
      } else {
        res(r || { ok: false, error: "sin_respuesta" });
      }
    });
  });
}

// Credenciales para una página: solo de entradas que encajan con esa URL,
// para que un marco de otra web no pueda pedir contraseñas ajenas.
async function credencialesPara(url, id) {
  const r = await nativo({ op: "para_url", url });
  if (!r.ok || !r.items.some((i) => i.id === id)) return { ok: false, error: "no_encaja" };
  return nativo({ op: "credenciales", id });
}

async function rellenarPestana(tab, id) {
  const cred = id ? await nativo({ op: "credenciales", id }) : null;
  let c = cred;
  if (!c) {
    const r = await nativo({ op: "para_url", url: tab.url });
    if (!r.ok || !r.items.length) return r.ok ? { ok: false, error: "sin_entradas" } : r;
    c = await nativo({ op: "credenciales", id: r.items[0].id });
  }
  if (c.ok) chrome.tabs.sendMessage(tab.id, { tipo: "rellenar", cred: c });
  return c.ok ? { ok: true } : c;
}

const TEXTOS = {
  sin_app: "Abre la app passOO en este Mac para rellenar.",
  cerrada: "Abre la app passOO en este Mac para rellenar.",
  bloqueado: "passOO está bloqueado: desbloquéalo en la app.",
  sin_entradas: "passOO no tiene entradas para esta web.",
};
const avisar = (tab, r) =>
  chrome.tabs.sendMessage(tab.id, { tipo: "aviso", texto: TEXTOS[r.error] || "No se pudo conectar con passOO." }, { frameId: 0 });

chrome.runtime.onMessage.addListener((m, sender, send) => {
  (async () => {
    const desdePagina = !!sender.tab;
    switch (m.tipo) {
      case "para_url":
        send(await nativo({ op: "para_url", url: desdePagina ? sender.url : m.url }));
        break;
      case "mostrar":
        send(desdePagina ? { ok: false } : await nativo({ op: "mostrar", id: m.id }));
        break;
      case "abrir_app": {
        const r = desdePagina ? { ok: false } : await nativo({ op: "abrir_app" });
        marcarConexion(!!r.ok);
        send(r);
        break;
      }
      case "ajustes":
        send(await chrome.storage.local.get({ autoRellenar: true }));
        break;
      case "credenciales":
        send(desdePagina ? await credencialesPara(sender.url, m.id) : { ok: false });
        break;
      case "buscar":
        send(desdePagina ? { ok: false } : await nativo({ op: "buscar", q: m.q }));
        break;
      case "copiar":
        send(desdePagina ? { ok: false } : await nativo({ op: "copiar", id: m.id, campo: m.campo }));
        break;
      case "rellenar_en_pestana": {
        if (desdePagina) return send({ ok: false });
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        send(tab ? await rellenarPestana(tab, m.id) : { ok: false });
        break;
      }
      default:
        send({ ok: false });
    }
  })();
  return true;
});

// Icono en color con la app abierta y desbloqueada; en gris si no.
const ICONOS = (p) => ({ 16: `iconos/${p}16.png`, 32: `iconos/${p}32.png` });
let conectada = null;
function marcarConexion(ok) {
  if (ok === conectada) return;
  conectada = ok;
  chrome.action.setIcon({ path: ICONOS(ok ? "" : "gris-") });
  chrome.action.setTitle({ title: ok ? "passOO" : "passOO · app cerrada o bloqueada" });
  if (!ok) chrome.action.setBadgeText({ text: "" });
}
async function comprobar() {
  const r = await nativo({ op: "estado" });
  marcarConexion(!!r.ok);
  return r;
}
chrome.runtime.onStartup.addListener(comprobar);
chrome.runtime.onInstalled.addListener(comprobar);
chrome.alarms.create("passoo", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(comprobar);
comprobar();

// Número de entradas de la web en el icono de la extensión (como la oficial).
async function contador(tabId, url) {
  if (!url || !/^https?:/.test(url)) return chrome.action.setBadgeText({ tabId, text: "" });
  const r = await nativo({ op: "para_url", url });
  marcarConexion(!!r.ok);
  const n = r.ok ? r.items.length : 0;
  chrome.action.setBadgeBackgroundColor({ tabId, color: "#4f86f7" });
  chrome.action.setBadgeTextColor && chrome.action.setBadgeTextColor({ tabId, color: "#ffffff" });
  chrome.action.setBadgeText({ tabId, text: n ? (n > 99 ? "99+" : String(n)) : "" });
}
chrome.tabs.onUpdated.addListener((id, info, tab) => {
  if (info.status === "complete" || info.url) contador(id, tab.url);
});
chrome.tabs.onActivated.addListener(({ tabId }) => chrome.tabs.get(tabId, (t) => t && contador(tabId, t.url)));
chrome.windows.onFocusChanged.addListener(async () => {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (t) contador(t.id, t.url);
});

chrome.commands.onCommand.addListener(async (cmd, tab) => {
  if (cmd !== "rellenar") return;
  const t = tab || (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (!t) return;
  const r = await rellenarPestana(t, null);
  if (!r.ok) avisar(t, r);
});
