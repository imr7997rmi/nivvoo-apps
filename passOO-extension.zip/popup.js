const $ = (s) => document.querySelector(s);
const lista = $("#lista");
const pie = $("#pie");
let filas = [];
let sel = 0;
let tab = null;

const enviar = (m) => chrome.runtime.sendMessage(m);

const DESCARGA = "https://raw.githubusercontent.com/imr7997rmi/nivvoo-apps/main/passOO-latest.zip";

// Error con su botón: abrir la app, o descargarla si no está instalada.
function error(r) {
  const noInstalada = r.error === "sin_app" && /not found|no encontr/i.test(r.detalle || "");
  if (noInstalada) return { texto: "passOO no está instalado en este Mac.", boton: "Descargar passOO", url: DESCARGA };
  if (r.error === "bloqueado") return { texto: "passOO está bloqueado.", boton: "Abrir passOO" };
  if (r.error === "sin_app" || r.error === "cerrada") return { texto: "passOO no está abierto.", boton: "Abrir passOO" };
  return { texto: "No se pudo conectar con passOO.", boton: "Abrir passOO" };
}

function pintar(secciones) {
  lista.innerHTML = "";
  filas = [];
  for (const [titulo, items] of secciones) {
    if (!items.length) continue;
    const s = document.createElement("div");
    s.className = "seccion";
    s.textContent = titulo;
    lista.appendChild(s);
    for (const it of items) {
      const f = document.createElement("div");
      f.className = "fila";
      f.innerHTML = `<div class="info"><div class="n"></div><div class="u"></div></div>
        <button class="ic principal" data-c="rellenar" title="Rellenar usuario y contraseña">${ICONOS.rellenar}</button>
        <button class="ic" data-c="usuario" title="Copiar usuario">${ICONOS.usuario}</button>
        <button class="ic" data-c="password" title="Copiar contraseña">${ICONOS.clave}</button>
        ${it.uri ? `<button class="ic" data-c="web" title="Ir a la web">${ICONOS.web}</button>` : ""}
        <button class="ic" data-c="ver" title="Editar en passOO (notas, adjuntos…)">${ICONOS.editar}</button>`;
      f.querySelector(".n").textContent = it.nombre;
      f.querySelector(".u").textContent = it.usuario || "";
      f.addEventListener("click", (e) => {
        const c = e.target.dataset && e.target.dataset.c;
        if (c === "usuario" || c === "password") copiar(it, c);
        else if (c === "ver") ver(it);
        else if (c === "web") web(it);
        else rellenar(it);
      });
      lista.appendChild(f);
      filas.push([f, it]);
    }
  }
  if (!filas.length) lista.innerHTML = `<div class="aviso">Sin entradas para esta web. Escribe para buscar.</div>`;
  sel = 0;
  marcar();
}

function marcar() {
  filas.forEach(([f], i) => f.classList.toggle("sel", i === sel));
  if (filas[sel]) filas[sel][0].scrollIntoView({ block: "nearest" });
}

// Iconos de trazo (estilo SF Symbols).
const ICONOS = {
  rellenar: `<svg viewBox="0 0 16 16"><path d="M13 3v4.5a2 2 0 0 1-2 2H3"/><path d="M6 6.5l-3 3 3 3"/></svg>`,
  usuario: `<svg viewBox="0 0 16 16"><circle cx="8" cy="5.5" r="2.7"/><path d="M2.8 14c.6-2.8 2.7-4.3 5.2-4.3s4.6 1.5 5.2 4.3"/></svg>`,
  clave: `<svg viewBox="0 0 16 16"><circle cx="5" cy="8" r="2.8"/><path d="M7.8 8h6M12 8v2.5M14 8v1.8"/></svg>`,
  web: `<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="6"/><ellipse cx="8" cy="8" rx="2.6" ry="6"/><path d="M2 8h12M3 4.8h10M3 11.2h10"/></svg>`,
  editar: `<svg viewBox="0 0 16 16"><path d="M10.6 2.6l2.8 2.8L5.8 13H3v-2.8z"/><path d="M9.2 4l2.8 2.8"/></svg>`,
};

function web(it) {
  const u = /^[a-z]+:\/\//i.test(it.uri) ? it.uri : "https://" + it.uri;
  chrome.tabs.create({ url: u });
  window.close();
}

async function ver(it) {
  const r = await enviar({ tipo: "mostrar", id: it.id });
  if (r && r.ok) window.close();
  else aviso(error(r || {}));
}

async function rellenar(it) {
  const r = await enviar({ tipo: "rellenar_en_pestana", id: it.id });
  if (r && r.ok) window.close();
  else aviso(error(r || {}));
}

async function copiar(it, campo) {
  const r = await enviar({ tipo: "copiar", id: it.id, campo });
  if (r && r.ok) {
    pie.textContent = (campo === "usuario" ? "Usuario" : "Contraseña") + " copiado · se borra en 30 s";
    pie.className = "ok";
  } else aviso(error(r || {}));
}

function aviso(e) {
  if (typeof e === "string") e = { texto: e };
  lista.innerHTML = `<div class="aviso"><div></div></div>`;
  lista.querySelector(".aviso div").textContent = e.texto;
  filas = [];
  if (!e.boton) return;
  const b = document.createElement(e.url ? "a" : "button");
  b.className = "accion";
  b.textContent = e.boton;
  if (e.url) {
    b.href = e.url;
    b.target = "_blank";
  } else {
    b.addEventListener("click", async () => {
      b.textContent = "Abriendo…";
      b.disabled = true;
      await enviar({ tipo: "abrir_app" });
      cargar();
    });
  }
  lista.querySelector(".aviso").appendChild(b);
}

async function cargar() {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const r = await enviar({ tipo: "para_url", url: tab ? tab.url : "" });
  if ($("#q").value.trim()) return; // el usuario ya está buscando
  if (!r || !r.ok) return aviso(error(r || {}));
  pintar([["Esta web", r.items]]);
}

let temporizador = null;
$("#q").addEventListener("input", (e) => {
  clearTimeout(temporizador);
  const q = e.target.value.trim();
  temporizador = setTimeout(async () => {
    if (!q) return cargar();
    const r = await enviar({ tipo: "buscar", q });
    if ($("#q").value.trim() !== q) return; // ya se escribió otra cosa
    if (!r || !r.ok) return aviso(error(r || {}));
    pintar([["Resultados", r.items]]);
  }, 60);
});

document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowDown" || e.key === "ArrowUp") {
    e.preventDefault();
    if (!filas.length) return;
    sel = (sel + (e.key === "ArrowDown" ? 1 : filas.length - 1)) % filas.length;
    marcar();
  } else if (e.key === "Enter" && filas[sel]) {
    e.preventDefault();
    rellenar(filas[sel][1]);
  }
});

chrome.storage.local.get({ autoRellenar: true }).then((a) => ($("#autoRellenar").checked = a.autoRellenar));
$("#autoRellenar").addEventListener("change", (e) => chrome.storage.local.set({ autoRellenar: e.target.checked }));

cargar();
