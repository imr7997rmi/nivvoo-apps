const $ = (s) => document.querySelector(s);
const lista = $("#lista");
const pie = $("#pie");
let filas = [];
let sel = 0;
let tab = null;

const enviar = (m) => chrome.runtime.sendMessage(m);

function error(r) {
  if (r.error === "bloqueado") return "passOO está bloqueado: desbloquéalo en la app.";
  if (r.error === "sin_app" || r.error === "cerrada") return "Abre la app passOO en este Mac.";
  return "No se pudo conectar con passOO.";
}

function pintar(secciones) {
  lista.innerHTML = "";
  filas = [];
  for (const [titulo, items] of secciones) {
    if (!items.length) continue;
    const s = document.createElement("div");
    s.className = "seccion";
    s.textContent = titulo;
    lista.appendChild(s);
    for (const it of items) {
      const f = document.createElement("div");
      f.className = "fila";
      f.innerHTML = `<div class="info"><div class="n"></div><div class="u"></div></div>
        <button data-c="usuario" title="Copiar usuario">Usuario</button>
        <button data-c="password" title="Copiar contraseña">Clave</button>`;
      f.querySelector(".n").textContent = it.nombre;
      f.querySelector(".u").textContent = it.usuario || "";
      f.addEventListener("click", (e) => {
        const c = e.target.dataset && e.target.dataset.c;
        if (c) copiar(it, c);
        else rellenar(it);
      });
      lista.appendChild(f);
      filas.push([f, it]);
    }
  }
  if (!filas.length) lista.innerHTML = `<div class="aviso">Sin entradas para esta web. Escribe para buscar.</div>`;
  sel = 0;
  marcar();
}

function marcar() {
  filas.forEach(([f], i) => f.classList.toggle("sel", i === sel));
  if (filas[sel]) filas[sel][0].scrollIntoView({ block: "nearest" });
}

async function rellenar(it) {
  const r = await enviar({ tipo: "rellenar_en_pestana", id: it.id });
  if (r && r.ok) window.close();
  else aviso(error(r || {}));
}

async function copiar(it, campo) {
  const r = await enviar({ tipo: "copiar", id: it.id, campo });
  if (r && r.ok) {
    pie.textContent = (campo === "usuario" ? "Usuario" : "Contraseña") + " copiado · se borra en 30 s";
    pie.className = "ok";
  } else aviso(error(r || {}));
}

function aviso(t) {
  lista.innerHTML = `<div class="aviso"></div>`;
  lista.firstChild.textContent = t;
  filas = [];
}

async function cargar() {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const r = await enviar({ tipo: "para_url", url: tab ? tab.url : "" });
  if (!r || !r.ok) return aviso(error(r || {}));
  pintar([["Esta web", r.items]]);
}

let temporizador = null;
$("#q").addEventListener("input", (e) => {
  clearTimeout(temporizador);
  const q = e.target.value.trim();
  temporizador = setTimeout(async () => {
    if (!q) return cargar();
    const r = await enviar({ tipo: "buscar", q });
    if (!r || !r.ok) return aviso(error(r || {}));
    pintar([["Resultados", r.items]]);
  }, 60);
});

document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowDown" || e.key === "ArrowUp") {
    e.preventDefault();
    if (!filas.length) return;
    sel = (sel + (e.key === "ArrowDown" ? 1 : filas.length - 1)) % filas.length;
    marcar();
  } else if (e.key === "Enter" && filas[sel]) {
    e.preventDefault();
    rellenar(filas[sel][1]);
  }
});

cargar();
