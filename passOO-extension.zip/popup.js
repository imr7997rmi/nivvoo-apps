const $ = (s) => document.querySelector(s);
const lista = $("#lista");
const pie = $("#pie");
let filas = [];
let sel = 0;
let tab = null;

const enviar = (m) => chrome.runtime.sendMessage(m);

const DESCARGA = "https://raw.githubusercontent.com/imr7997rmi/nivvoo-apps/main/passOO-latest.zip";

// Error con su botón: abrir la app, o descargarla si no está instalada.
function error(r) {
  const noInstalada = r.error === "sin_app" && /not found|no encontr/i.test(r.detalle || "");
  if (noInstalada) return { texto: "passOO no está instalado en este Mac.", boton: "Descargar passOO", url: DESCARGA };
  if (r.error === "bloqueado") return { texto: "passOO está bloqueado.", boton: "Abrir passOO" };
  if (r.error === "sin_app" || r.error === "cerrada") return { texto: "passOO no está abierto.", boton: "Abrir passOO" };
  return { texto: "No se pudo conectar con passOO.", boton: "Abrir passOO" };
}

function pintar(secciones) {
  lista.innerHTML = "";
  filas = [];
  for (const [titulo, items] of secciones) {
    if (!items.length) continue;
    const s = document.createElement("div");
    s.className = "seccion";
    s.textContent = titulo;
    lista.appendChild(s);
    for (const it of items) {
      const f = document.createElement("div");
      f.className = "fila";
      f.innerHTML = `<div class="info"><div class="n"></div><div class="u"></div></div>
        <button data-c="usuario" title="Copiar usuario">Usuario</button>
        <button data-c="password" title="Copiar contraseña">Clave</button>`;
      f.querySelector(".n").textContent = it.nombre;
      f.querySelector(".u").textContent = it.usuario || "";
      f.addEventListener("click", (e) => {
        const c = e.target.dataset && e.target.dataset.c;
        if (c) copiar(it, c);
        else rellenar(it);
      });
      lista.appendChild(f);
      filas.push([f, it]);
    }
  }
  if (!filas.length) lista.innerHTML = `<div class="aviso">Sin entradas para esta web. Escribe para buscar.</div>`;
  sel = 0;
  marcar();
}

function marcar() {
  filas.forEach(([f], i) => f.classList.toggle("sel", i === sel));
  if (filas[sel]) filas[sel][0].scrollIntoView({ block: "nearest" });
}

async function rellenar(it) {
  const r = await enviar({ tipo: "rellenar_en_pestana", id: it.id });
  if (r && r.ok) window.close();
  else aviso(error(r || {}));
}

async function copiar(it, campo) {
  const r = await enviar({ tipo: "copiar", id: it.id, campo });
  if (r && r.ok) {
    pie.textContent = (campo === "usuario" ? "Usuario" : "Contraseña") + " copiado · se borra en 30 s";
    pie.className = "ok";
  } else aviso(error(r || {}));
}

function aviso(e) {
  if (typeof e === "string") e = { texto: e };
  lista.innerHTML = `<div class="aviso"><div></div></div>`;
  lista.querySelector(".aviso div").textContent = e.texto;
  filas = [];
  if (!e.boton) return;
  const b = document.createElement(e.url ? "a" : "button");
  b.className = "accion";
  b.textContent = e.boton;
  if (e.url) {
    b.href = e.url;
    b.target = "_blank";
  } else {
    b.addEventListener("click", async () => {
      b.textContent = "Abriendo…";
      b.disabled = true;
      await enviar({ tipo: "abrir_app" });
      cargar();
    });
  }
  lista.querySelector(".aviso").appendChild(b);
}

async function cargar() {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const r = await enviar({ tipo: "para_url", url: tab ? tab.url : "" });
  if ($("#q").value.trim()) return; // el usuario ya está buscando
  if (!r || !r.ok) return aviso(error(r || {}));
  pintar([["Esta web", r.items]]);
}

let temporizador = null;
$("#q").addEventListener("input", (e) => {
  clearTimeout(temporizador);
  const q = e.target.value.trim();
  temporizador = setTimeout(async () => {
    if (!q) return cargar();
    const r = await enviar({ tipo: "buscar", q });
    if ($("#q").value.trim() !== q) return; // ya se escribió otra cosa
    if (!r || !r.ok) return aviso(error(r || {}));
    pintar([["Resultados", r.items]]);
  }, 60);
});

document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowDown" || e.key === "ArrowUp") {
    e.preventDefault();
    if (!filas.length) return;
    sel = (sel + (e.key === "ArrowDown" ? 1 : filas.length - 1)) % filas.length;
    marcar();
  } else if (e.key === "Enter" && filas[sel]) {
    e.preventDefault();
    rellenar(filas[sel][1]);
  }
});

chrome.storage.local.get({ autoRellenar: true }).then((a) => ($("#autoRellenar").checked = a.autoRellenar));
$("#autoRellenar").addEventListener("change", (e) => chrome.storage.local.set({ autoRellenar: e.target.checked }));

cargar();
