// passOO — puente entre webauthn.js (mundo de la página) y la extensión, y la
// ventanita para elegir la llave de acceso.
(() => {
  if (window.__passooPasskeys) return;
  window.__passooPasskeys = true;

  const ICONO = chrome.runtime.getURL("iconos/32.png");
  const CSS = `
    :host { all: initial; }
    .fondo { position: fixed; inset: 0; z-index: 2147483647; background: rgba(0,0,0,.35); display: flex; align-items: center; justify-content: center; }
    .caja { width: 360px; max-height: 70vh; overflow: auto; background: #1c1c1e; color: #f2f2f2; border: 1px solid #3a3a3c; border-radius: 14px;
      box-shadow: 0 20px 50px rgba(0,0,0,.5); font: 13px -apple-system, BlinkMacSystemFont, sans-serif; padding: 16px; }
    .menu { position: fixed; z-index: 2147483647; min-width: 260px; background: #1c1c1e; color: #f2f2f2; border: 1px solid #3a3a3c;
      border-radius: 10px; box-shadow: 0 8px 28px rgba(0,0,0,.35); font: 13px -apple-system, BlinkMacSystemFont, sans-serif; overflow: hidden; }
    .cab { display: flex; align-items: center; gap: 8px; font-weight: 600; }
    .menu .cab { padding: 8px 12px; font-size: 11px; color: #8e8e93; font-weight: 400; border-bottom: 1px solid #2c2c2e; }
    .cab img { width: 18px; height: 18px; } .menu .cab img { width: 16px; height: 16px; }
    .sub { color: #8e8e93; margin: 6px 0 12px; }
    .fila { display: flex; align-items: center; gap: 10px; padding: 9px 10px; border-radius: 8px; cursor: pointer; }
    .menu .fila { border-radius: 0; padding: 8px 12px; }
    .fila:hover { background: rgba(79,134,247,.22); }
    .llave { width: 26px; height: 26px; border-radius: 7px; background: #2a2a2c; display: flex; align-items: center; justify-content: center; flex: none; }
    .llave svg { width: 15px; height: 15px; fill: none; stroke: #4f86f7; stroke-width: 1.6; stroke-linecap: round; }
    .n { font-weight: 600; } .u { color: #8e8e93; font-size: 12px; }
    .acciones { display: flex; justify-content: space-between; margin-top: 14px; }
    button { height: 30px; padding: 0 12px; border-radius: 8px; border: 1px solid #3a3a3c; background: #2a2a2c; color: #f2f2f2;
      font: 13px -apple-system, sans-serif; cursor: pointer; }`;
  const LLAVE = `<svg viewBox="0 0 16 16"><circle cx="5" cy="8" r="3"/><path d="M8 8h6.5M12 8v2.6M14.5 8v2"/></svg>`;

  let abierta = null; // {host, n}

  function cerrar() {
    if (abierta) abierta.host.remove();
    abierta = null;
  }

  function filas(cont, items, elegir) {
    for (const it of items) {
      const f = document.createElement("div");
      f.className = "fila";
      f.innerHTML = `<div class="llave">${LLAVE}</div><div><div class="n"></div><div class="u"></div></div>`;
      f.querySelector(".n").textContent = it.usuario || it.nombre;
      f.querySelector(".u").textContent = it.usuario ? it.nombre : "";
      f.addEventListener("mousedown", (e) => {
        e.preventDefault();
        elegir(it);
      });
      cont.appendChild(f);
    }
  }

  // Inicio de sesión normal: ventanita en el centro.
  function elegirModal(n, rpId, items) {
    return new Promise((res) => {
      cerrar();
      const host = document.createElement("passoo-passkey");
      const r = host.attachShadow({ mode: "closed" });
      r.innerHTML = `<style>${CSS}</style><div class="fondo"><div class="caja">
        <div class="cab"><img src="${ICONO}">Iniciar sesión con una llave de acceso</div>
        <div class="sub"></div><div class="lista"></div>
        <div class="acciones"><button class="otro">Usar otro dispositivo</button><button class="no">Cancelar</button></div></div></div>`;
      r.querySelector(".sub").textContent = `passOO tiene ${items.length === 1 ? "una llave" : items.length + " llaves"} para ${rpId}`;
      const fin = (x) => {
        cerrar();
        res(x);
      };
      filas(r.querySelector(".lista"), items, fin);
      r.querySelector(".otro").addEventListener("click", () => fin("otro"));
      r.querySelector(".no").addEventListener("click", () => fin(null));
      r.querySelector(".fondo").addEventListener("mousedown", (e) => e.target === e.currentTarget && fin(null));
      document.documentElement.appendChild(host);
      abierta = { host, n, fin };
    });
  }

  // Webs que ofrecen la llave en el campo de usuario (mediation: conditional):
  // la petición queda a la espera y se ofrece al enfocar ese campo.
  function elegirCondicional(n, items) {
    return new Promise((res) => {
      const esCampo = (el) =>
        el instanceof HTMLInputElement &&
        (/webauthn/i.test(el.autocomplete || "") || /user|usuari|login|e-?mail|correo|account|ident/i.test(`${el.name} ${el.id} ${el.type} ${el.autocomplete}`));
      const mostrar = (el) => {
        if (abierta) return;
        const host = document.createElement("passoo-passkey");
        const r = host.attachShadow({ mode: "closed" });
        r.innerHTML = `<style>${CSS}</style><div class="menu"><div class="cab"><img src="${ICONO}">passOO · llave de acceso</div><div class="lista"></div></div>`;
        const rect = el.getBoundingClientRect();
        const m = r.querySelector(".menu");
        m.style.left = Math.max(4, rect.left) + "px";
        m.style.top = rect.bottom + 4 + "px";
        filas(r.querySelector(".lista"), items, (it) => {
          quitar();
          res(it);
        });
        document.documentElement.appendChild(host);
        abierta = { host, n, fin: () => {} };
      };
      const alEnfocar = (e) => esCampo(e.target) && mostrar(e.target);
      const alSalir = () => setTimeout(cerrar, 150);
      const quitar = () => {
        document.removeEventListener("focusin", alEnfocar, true);
        document.removeEventListener("focusout", alSalir, true);
        cerrar();
      };
      document.addEventListener("focusin", alEnfocar, true);
      document.addEventListener("focusout", alSalir, true);
      if (esCampo(document.activeElement)) mostrar(document.activeElement);
      pendienteCondicional = { n, quitar, res };
    });
  }
  let pendienteCondicional = null;

  window.addEventListener("message", async (e) => {
    if (e.source !== window || !e.data || e.data.__passoo !== "peticion") return;
    const d = e.data;
    const responder = (x) => window.postMessage({ __passoo: "respuesta", n: d.n, ...x }, "*");
    if (d.cancelar) {
      if (pendienteCondicional && pendienteCondicional.n === d.n) pendienteCondicional.quitar();
      if (abierta && abierta.n === d.n) abierta.fin(null);
      return;
    }
    const r = await chrome.runtime.sendMessage({ tipo: "passkey_listar", rpId: d.rpId, allow: d.allow }).catch(() => null);
    if (!r || !r.ok || !r.items || !r.items.length) return responder({ fallback: true });
    if (pendienteCondicional) pendienteCondicional.quitar();
    const elegido = d.conditional ? await elegirCondicional(d.n, r.items) : await elegirModal(d.n, d.rpId, r.items);
    if (elegido === "otro") return responder({ fallback: true });
    if (!elegido) return responder({ cancelado: true });
    const f = await chrome.runtime
      .sendMessage({ tipo: "passkey_firmar", id: elegido.id, credId: elegido.credId, rpId: d.rpId, clientData: d.clientData })
      .catch(() => null);
    if (!f || !f.ok) return responder({ fallback: true });
    responder({ usar: true, credId: f.credId, authenticatorData: f.authenticatorData, signature: f.signature, userHandle: f.userHandle });
  });
})();
