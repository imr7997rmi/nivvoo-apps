// passOO — se ejecuta en el mundo de la página (MAIN) para atender
// navigator.credentials.get con las llaves de acceso guardadas en passOO.
// No ve ni guarda claves: pide la firma a la app por medio de la extensión.
// Si passOO no tiene llave para la web, se deja pasar a la del navegador.
(() => {
  const cred = navigator.credentials;
  if (!cred || typeof cred.get !== "function" || window.__passooWebauthn) return;
  window.__passooWebauthn = true;
  const original = cred.get.bind(cred);

  const aBytes = (b) =>
    b instanceof ArrayBuffer ? new Uint8Array(b) : new Uint8Array(b.buffer, b.byteOffset, b.byteLength);
  const b64u = (b) => {
    let s = "";
    for (const x of aBytes(b)) s += String.fromCharCode(x);
    return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  };
  const deb64u = (s) => {
    s = s.replace(/-/g, "+").replace(/_/g, "/");
    while (s.length % 4) s += "=";
    const t = atob(s);
    const u = new Uint8Array(t.length);
    for (let i = 0; i < t.length; i++) u[i] = t.charCodeAt(i);
    return u.buffer;
  };

  let n = 0;
  const esperando = new Map();
  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data || e.data.__passoo !== "respuesta") return;
    const f = esperando.get(e.data.n);
    if (f) {
      esperando.delete(e.data.n);
      f(e.data);
    }
  });
  const pedir = (k, datos) =>
    new Promise((res) => {
      esperando.set(k, res);
      window.postMessage({ __passoo: "peticion", n: k, ...datos }, location.origin === "null" ? "*" : location.origin);
    });

  function credencial(r, clientData) {
    const respuesta = {
      clientDataJSON: clientData.buffer,
      authenticatorData: deb64u(r.authenticatorData),
      signature: deb64u(r.signature),
      userHandle: r.userHandle ? deb64u(r.userHandle) : null,
    };
    Object.setPrototypeOf(respuesta, AuthenticatorAssertionResponse.prototype);
    const c = {
      id: r.credId,
      rawId: deb64u(r.credId),
      type: "public-key",
      authenticatorAttachment: "platform",
      response: respuesta,
      getClientExtensionResults: () => ({}),
      toJSON: () => ({
        id: r.credId,
        rawId: r.credId,
        type: "public-key",
        authenticatorAttachment: "platform",
        clientExtensionResults: {},
        response: {
          clientDataJSON: b64u(clientData),
          authenticatorData: r.authenticatorData,
          signature: r.signature,
          userHandle: r.userHandle || undefined,
        },
      }),
    };
    Object.setPrototypeOf(c, PublicKeyCredential.prototype);
    return c;
  }

  cred.get = async function (opciones) {
    const pk = opciones && opciones.publicKey;
    if (!pk || !pk.challenge) return original(opciones);
    const rpId = pk.rpId || location.hostname;
    const clientData = new TextEncoder().encode(
      JSON.stringify({ type: "webauthn.get", challenge: b64u(pk.challenge), origin: location.origin, crossOrigin: window !== top })
    );
    const k = ++n;
    const signal = opciones.signal;
    if (signal && signal.aborted) throw new DOMException("Operación cancelada", "AbortError");
    const respuesta = pedir(k, {
      rpId,
      allow: (pk.allowCredentials || []).map((c) => b64u(c.id)),
      clientData: b64u(clientData),
      conditional: opciones.mediation === "conditional",
    });
    const cancelada = new Promise((_, rej) => {
      if (signal)
        signal.addEventListener("abort", () => {
          esperando.delete(k);
          window.postMessage({ __passoo: "peticion", n: k, cancelar: true }, "*");
          rej(new DOMException("Operación cancelada", "AbortError"));
        });
    });
    const r = await Promise.race([respuesta, cancelada]);
    if (r.usar) return credencial(r, clientData);
    if (r.cancelado) throw new DOMException("La operación no se permitió o se canceló.", "NotAllowedError");
    return original(opciones); // sin llave en passOO: la del navegador
  };
})();
